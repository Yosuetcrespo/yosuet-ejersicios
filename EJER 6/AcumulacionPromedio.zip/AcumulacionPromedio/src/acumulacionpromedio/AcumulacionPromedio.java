/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package acumulacionpromedio;

import java.util.Scanner;

public class AcumulacionPromedio {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double suma = 0;
        int contador = 0;
        
        System.out.println("Ingrese números mayores o iguales a cero (negativo para terminar):");
        double num = scanner.nextDouble();
        
        while (num >= 0) {
            suma += num;
            contador++;
            num = scanner.nextDouble();
        }
        
        if (contador > 0) {
            double promedio = suma / contador;
            System.out.println("Suma total: " + suma);
            System.out.println("Promedio: " + promedio);
        } else {
            System.out.println("No se ingresaron números válidos.");
        }
        scanner.close();
    }
}

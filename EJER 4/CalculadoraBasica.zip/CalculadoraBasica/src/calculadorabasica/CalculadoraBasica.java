/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadorabasica;

import java.util.Scanner;

public class CalculadoraBasica {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Menú de operaciones:");
            System.out.println("1. Suma");
            System.out.println("2. Resta");
            System.out.println("3. Multiplicación");
            System.out.println("4. División");
            System.out.print("Seleccione una opción (1-4): ");
            int opcion = scanner.nextInt();
            
            if (opcion >= 1 && opcion <= 4) {
                System.out.print("Ingrese el primer número: ");
                double num1 = scanner.nextDouble();
                System.out.print("Ingrese el segundo número: ");
                double num2 = scanner.nextDouble();
                double resultado = 0;
                
                switch (opcion) {
                    case 1 -> resultado = num1 + num2;
                    case 2 -> resultado = num1 - num2;
                    case 3 -> resultado = num1 * num2;
                    case 4 -> {
                        if (num2 != 0) {
                            resultado = num1 / num2;
                        } else {
                            System.out.println("Error: No se puede dividir por cero.");
                            return;
                        }
                    }
                }
                System.out.println("El resultado es: " + resultado);
            } else {
                System.out.println("Opción no válida.");
            }
        }
    }
}

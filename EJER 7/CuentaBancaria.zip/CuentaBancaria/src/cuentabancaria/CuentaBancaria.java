/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package CuentaBancaria;

/**
 * 
 *
 * 
 * @author SENA
 */

public class CuentaBancaria {
    
    private String titular;
    private double saldo;
    
    public CuentaBancaria(String titular, double saldoInicial) {
        this.titular = titular;
        this.saldo = saldoInicial;
    }
    
    public void depositar(double cantidad) {
        if (cantidad > 0) {
            saldo += cantidad;
            System.out.println(" Depósito exitoso. Nuevo saldo: $" + saldo);
        } else {
            System.out.println(" Error: La cantidad a depositar debe ser mayor a cero.");
        }
    }
    
    public void retirar(double cantidad) {
        if (cantidad > 0) {
            if (cantidad <= saldo) {
                saldo -= cantidad;
                System.out.println(" Retiro exitoso. Nuevo saldo: $" + saldo);
            } else {
                System.out.println(" Error: Fondos insuficientes. Saldo actual: $" + saldo);
            }
        } else {
            System.out.println(" Error: La cantidad a retirar debe ser mayor a cero.");
        }
    }
    
    public double consultarSaldo() {
        return saldo;
    }
    
    public String getTitular() {
        return titular;
    }
}
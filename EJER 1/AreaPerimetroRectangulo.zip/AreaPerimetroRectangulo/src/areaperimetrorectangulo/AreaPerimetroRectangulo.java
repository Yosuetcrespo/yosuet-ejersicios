/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package areaperimetrorectangulo;

import java.util.Scanner;

public class AreaPerimetroRectangulo {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Ingrese la base del rectángulo: ");
            double base = scanner.nextDouble();
            System.out.print("Ingrese la altura del rectángulo: ");
            double altura = scanner.nextDouble();
            
            double area = base * altura;
            double perimetro = 2 * (base + altura);
            
            System.out.println("El área es: " + area);
            System.out.println("El perímetro es: " + perimetro);
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package conversiontemperatura;

import java.util.Scanner;

public class ConversionTemperatura {
    public static void main(String[] args) {
        double FACTOR_CONVERSION = 9.0 / 5.0;
        double AJUSTE = 32.0;
        
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Ingrese la temperatura en grados Celsius: ");
            double celsius = scanner.nextDouble();
            
            double fahrenheit = (celsius * FACTOR_CONVERSION) + AJUSTE;
            System.out.println("La temperatura en Fahrenheit es: " + fahrenheit);
        }
    }
}

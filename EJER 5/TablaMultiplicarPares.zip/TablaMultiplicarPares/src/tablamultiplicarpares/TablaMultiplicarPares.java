/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tablamultiplicarpares;

import java.util.Scanner;

public class TablaMultiplicarPares {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Ingrese un número entero N: ");
            int N = scanner.nextInt();
            int contadorPares = 0;
            
            for (int i = 1; i <= 10; i++) {
                int resultado = N * i;
                System.out.println(N + " x " + i + " = " + resultado);
                if (resultado % 2 == 0) {
                    contadorPares++;
                }
            }
            System.out.println("Cantidad de resultados pares: " + contadorPares);
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package paridadsigno;

import java.util.Scanner;

public class ParidadSigno {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Ingrese un número entero: ");
            int num = scanner.nextInt();
            
            if (num == 0) {
                System.out.println("El número es cero (neutro).");
            } else {
                if (num > 0) {
                    System.out.println("El número es positivo.");
                } else {
                    System.out.println("El número es negativo.");
                }
                
                if (num % 2 == 0) {
                    System.out.println("Además, es par.");
                } else {
                    System.out.println("Además, es impar.");
                }
            }
        }
    }
}
